# Fashion concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/ReGGae/pen/bmyYEj](https://codepen.io/ReGGae/pen/bmyYEj).

Based on .Nathan RIley's dribbble shot https://dribbble.com/shots/5475422-Kyoto-Black-Look-book-Live-Demo .