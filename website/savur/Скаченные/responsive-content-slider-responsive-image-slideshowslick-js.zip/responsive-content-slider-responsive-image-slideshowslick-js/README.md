# Responsive Content Slider / Responsive Image Slideshow - Slick JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/codegrid/pen/zYOQEYO](https://codepen.io/codegrid/pen/zYOQEYO).

